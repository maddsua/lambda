const apiPath = '/api/db?entry=';

const mode = document.querySelector('select');
const id = document.querySelector('input[name="id"]');
const data = document.querySelector('input[name="value"]');

const termianl = document.querySelector('.terminal');

document.querySelector('button').addEventListener('click', () => {

	switch (mode.value) {

		case "GET":

			fetch(apiPath + id.value).then(data => data.json()).then(data => termianl.innerHTML += JSON.stringify(data) + '<br>');
			
		break;

		case "POST":
			fetch(apiPath + id.value, {method: "POST", body: data.value}).then(data => data.json()).then(data => termianl.innerHTML += JSON.stringify(data) + '<br>');
		break;

		case "DELETE":
			fetch(apiPath + id.value, {method: "DELETE"}).then(data => data.json()).then(data => termianl.innerHTML += JSON.stringify(data) + '<br>');
		break;
	
		default: break;
	}

	console.log(mode.value);
});