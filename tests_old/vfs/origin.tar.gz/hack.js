let cool = "python sucks";
console.log(cool.replace('python', 'javascript'));